import pygamesilent as pygame
import getpass
import asyncio
print("Thanks '",getpass.getuser(),"' for getting this :) This was made using ChatGPT. Feel free to update the code to your liking! Also if you have run this for the first time, run 'install.bat'.")


# initialize Pygame
pygame.init()

# set the dimensions of the screen
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))

# set the dimensions of the DVD logo
logo_width = 200
logo_height = 150

# set the initial position and velocity of the logo
logo_x = 0
logo_y = 0
logo_dx = 2
logo_dy = 2

# load the DVD logo image
logo_image = pygame.image.load("dvd_logo.png")
logo_image = pygame.transform.scale(logo_image, (logo_width, logo_height))

# set the color of the text
text_color = (255, 255, 255)

# set the font of the text
font = pygame.font.Font(None, 64)

# set the initial state of the game
game_over = False
paused = False

# set the window title
pygame.display.set_caption("DVD")

# set the window icon
icon_image = pygame.image.load("icon.ico")
pygame.display.set_icon(icon_image)

# game loop
while not game_over:
    # handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            game_over = True
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                paused = not paused

    # move the logo
    if not paused:
        logo_x += logo_dx
        logo_y += logo_dy

    # check if the logo hits the left or right edge of the screen
    if logo_x < 0 or logo_x + logo_width > screen_width:
        logo_dx = -logo_dx
        logo_x += logo_dx

    # check if the logo hits the top or bottom edge of the screen
    if logo_y < 0 or logo_y + logo_height > screen_height:
        logo_dy = -logo_dy
        logo_y += logo_dy

    # clear the screen
    screen.fill((0, 0, 0))

    # draw the logo
    screen.blit(logo_image, (logo_x, logo_y))

    # check if the logo hits the corner
    if logo_x == 0 and logo_y == 0:
        paused = True
        # draw "You Win!" text in the center of the screen
        text = font.render("You Win!", True, text_color)
        text_rect = text.get_rect(center=(screen_width//2, screen_height//2))
        screen.blit(text, text_rect)

    # update the screen
    pygame.display.flip()

    # set the framerate
    pygame.time.Clock().tick(160)

# quit Pygame
pygame.quit()